package com.example.blockblast

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.min
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(246, 248, 255)
        window.navigationBarColor = android.graphics.Color.rgb(246, 248, 255)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContentView(BlockBlastView(this))
    }
}

private data class Piece(val cells: List<Pair<Int, Int>>, val color: Int)

private class BlockBlastView(context: Context) : View(context) {
    private val bg = android.graphics.Color.rgb(246, 248, 255)
    private val ink = android.graphics.Color.rgb(31, 42, 68)
    private val muted = android.graphics.Color.rgb(112, 126, 154)
    private val gridBg = android.graphics.Color.rgb(225, 232, 246)
    private val colors = listOf(
        android.graphics.Color.rgb(69, 129, 255),
        android.graphics.Color.rgb(255, 178, 54),
        android.graphics.Color.rgb(42, 190, 137),
        android.graphics.Color.rgb(173, 105, 244),
        android.graphics.Color.rgb(255, 101, 125),
        android.graphics.Color.rgb(43, 190, 207)
    )
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val board = Array(10) { IntArray(10) }
    private val pieces = MutableList(3) { randomPiece() }
    private var selected = 0
    private var score = 0
    private var best = 0
    private var gameOver = false
    private var boardLeft = 0f
    private var boardTop = 0f
    private var cell = 0f
    private var pieceTop = 0f
    private var pieceAreaHeight = 0f
    private var lastCleared = false

    private val shapes = listOf(
        listOf(0 to 0),
        listOf(0 to 0, 1 to 0),
        listOf(0 to 0, 0 to 1),
        listOf(0 to 0, 1 to 0, 2 to 0),
        listOf(0 to 0, 0 to 1, 0 to 2),
        listOf(0 to 0, 1 to 0, 0 to 1, 1 to 1),
        listOf(0 to 0, 1 to 0, 2 to 0, 1 to 1),
        listOf(0 to 0, 0 to 1, 0 to 2, 1 to 2),
        listOf(0 to 0, 1 to 0, 2 to 0, 2 to 1),
        listOf(0 to 0, 1 to 0, 2 to 0, 0 to 1, 1 to 1, 2 to 1),
        listOf(0 to 0, 0 to 1, 1 to 1, 1 to 2),
        listOf(0 to 0, 1 to 0, 2 to 0, 0 to 1),
        listOf(0 to 0, 1 to 0, 1 to 1, 2 to 1),
        listOf(0 to 0, 0 to 1, 0 to 2, 1 to 0, 1 to 1, 1 to 2)
    )

    private fun randomPiece(): Piece = Piece(shapes[Random.nextInt(shapes.size)], colors.random())

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(bg)
        drawText(canvas, "BLOCK BLAST", width / 2f, 58f, 26f, ink, true, Paint.Align.CENTER)
        drawText(canvas, "Fit the blocks. Clear lines. Beat your best.", width / 2f, 87f, 12f, muted, false, Paint.Align.CENTER)

        val margin = width * 0.055f
        val cardTop = 112f
        val cardBottom = height * 0.68f
        val available = min(width - 2 * margin, cardBottom - cardTop - 18f)
        cell = available / 10f
        boardLeft = (width - cell * 10f) / 2f
        boardTop = cardTop + (cardBottom - cardTop - cell * 10f) / 2f

        rounded(canvas, boardLeft - 7f, boardTop - 7f, boardLeft + cell * 10f + 7f, boardTop + cell * 10f + 7f, 18f, android.graphics.Color.WHITE)
        for (r in 0 until 10) for (c in 0 until 10) {
            val l = boardLeft + c * cell + 2f
            val t = boardTop + r * cell + 2f
            rounded(canvas, l, t, l + cell - 4f, t + cell - 4f, 5f, if (board[r][c] == 0) gridBg else board[r][c])
            if (board[r][c] != 0) {
                rounded(canvas, l + 1f, t + 1f, l + cell - 5f, t + cell - 5f, 5f, lighten(board[r][c]))
            }
        }

        val scoreY = boardTop + cell * 10f + 32f
        drawText(canvas, "SCORE", width * .28f, scoreY, 11f, muted, true, Paint.Align.CENTER)
        drawText(canvas, score.toString(), width * .28f, scoreY + 28f, 25f, ink, true, Paint.Align.CENTER)
        drawText(canvas, "BEST", width * .72f, scoreY, 11f, muted, true, Paint.Align.CENTER)
        drawText(canvas, best.toString(), width * .72f, scoreY + 28f, 25f, ink, true, Paint.Align.CENTER)

        pieceTop = scoreY + 64f
        pieceAreaHeight = height - pieceTop - 18f
        drawText(canvas, "TAP A BLOCK, THEN TAP THE BOARD", width / 2f, pieceTop + 2f, 10f, muted, true, Paint.Align.CENTER)
        val slotWidth = width / 3f
        for (i in 0..2) {
            val cx = slotWidth * (i + .5f)
            val slotTop = pieceTop + 17f
            val slotBottom = height - 12f
            rounded(canvas, cx - slotWidth * .43f, slotTop, cx + slotWidth * .43f, slotBottom, 14f,
                if (i == selected && pieces[i].cells.isNotEmpty() && !gameOver) android.graphics.Color.rgb(229, 237, 255) else android.graphics.Color.WHITE)
            if (pieces[i].cells.isNotEmpty()) drawPiece(canvas, pieces[i], cx, (slotTop + slotBottom) / 2f, min(slotWidth / 5.4f, 21f))
            drawText(canvas, "${i + 1}", cx, slotBottom - 7f, 10f, muted, true, Paint.Align.CENTER)
        }

        if (gameOver) {
            paint.color = android.graphics.Color.argb(185, 24, 35, 60)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            rounded(canvas, width * .10f, height * .36f, width * .90f, height * .63f, 24f, android.graphics.Color.WHITE)
            drawText(canvas, "GAME OVER", width / 2f, height * .425f, 27f, ink, true, Paint.Align.CENTER)
            drawText(canvas, "Final score: $score", width / 2f, height * .47f, 16f, muted, false, Paint.Align.CENTER)
            rounded(canvas, width * .25f, height * .515f, width * .75f, height * .575f, 16f, colors[0])
            drawText(canvas, "PLAY AGAIN", width / 2f, height * .552f, 14f, android.graphics.Color.WHITE, true, Paint.Align.CENTER)
        }
    }

    private fun drawPiece(canvas: Canvas, piece: Piece, centerX: Float, centerY: Float, unit: Float) {
        val maxX = piece.cells.maxOf { it.first } + 1
        val maxY = piece.cells.maxOf { it.second } + 1
        val startX = centerX - maxX * unit / 2f
        val startY = centerY - maxY * unit / 2f
        for ((x, y) in piece.cells) {
            val l = startX + x * unit + 1f
            val t = startY + y * unit + 1f
            rounded(canvas, l, t, l + unit - 3f, t + unit - 3f, 4f, piece.color)
            rounded(canvas, l + 2f, t + 2f, l + unit - 6f, t + unit * .28f, 3f, lighten(piece.color))
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val x = event.x
        val y = event.y
        if (gameOver) {
            if (y in (height * .36f)..(height * .63f)) resetGame()
            invalidate()
            return true
        }
        if (y >= pieceTop + 12f) {
            val slot = (x / (width / 3f)).toInt().coerceIn(0, 2)
            if (pieces[slot].cells.isNotEmpty()) selected = slot
            invalidate()
            return true
        }
        if (x >= boardLeft && x < boardLeft + cell * 10f && y >= boardTop && y < boardTop + cell * 10f) {
            val c = ((x - boardLeft) / cell).toInt()
            val r = ((y - boardTop) / cell).toInt()
            placePiece(r, c)
            invalidate()
        }
        return true
    }

    private fun placePiece(row: Int, col: Int) {
        val piece = pieces[selected]
        if (piece.cells.isEmpty()) return
        if (!piece.cells.all { (x, y) ->
            val rr = row + y; val cc = col + x
            rr in 0..9 && cc in 0..9 && board[rr][cc] == 0
        }) return

        for ((x, y) in piece.cells) board[row + y][col + x] = piece.color
        score += piece.cells.size
        best = maxOf(best, score)

        val fullRows = (0..9).filter { r -> (0..9).all { c -> board[r][c] != 0 } }
        val fullCols = (0..9).filter { c -> (0..9).all { r -> board[r][c] != 0 } }
        for (r in fullRows) for (c in 0..9) board[r][c] = 0
        for (c in fullCols) for (r in 0..9) board[r][c] = 0
        val cleared = fullRows.size + fullCols.size
        if (cleared > 0) {
            score += cleared * 10
            best = maxOf(best, score)
            vibrate()
        }

        pieces[selected] = Piece(emptyList(), piece.color)
        if (pieces.all { it.cells.isEmpty() }) {
            for (i in 0..2) pieces[i] = randomPiece()
            selected = 0
        }
        gameOver = pieces.filter { it.cells.isNotEmpty() }.none { p -> canFit(p) }
    }

    private fun canFit(piece: Piece): Boolean {
        for (r in 0..9) for (c in 0..9) {
            if (piece.cells.all { (x, y) ->
                val rr = r + y; val cc = c + x
                rr in 0..9 && cc in 0..9 && board[rr][cc] == 0
            }) return true
        }
        return false
    }

    private fun vibrate() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) vibrator.vibrate(VibrationEffect.createOneShot(90, VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(90)
                }
            }
        } catch (_: Exception) { }
    }

    private fun resetGame() {
        for (r in 0..9) for (c in 0..9) board[r][c] = 0
        score = 0
        gameOver = false
        selected = 0
        for (i in 0..2) pieces[i] = randomPiece()
    }

    private fun drawText(canvas: Canvas, text: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean, align: Paint.Align) {
        paint.color = color
        paint.textSize = size * resources.displayMetrics.scaledDensity
        paint.typeface = if (bold) android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) else android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        paint.textAlign = align
        paint.style = Paint.Style.FILL
        canvas.drawText(text, x, y, paint)
    }

    private fun rounded(canvas: Canvas, l: Float, t: Float, r: Float, b: Float, radius: Float, color: Int) {
        paint.color = color
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(RectF(l, t, r, b), radius, radius, paint)
    }

    private fun lighten(color: Int): Int {
        val red = min(255, android.graphics.Color.red(color) + 35)
        val green = min(255, android.graphics.Color.green(color) + 35)
        val blue = min(255, android.graphics.Color.blue(color) + 35)
        return android.graphics.Color.rgb(red, green, blue)
    }
}
