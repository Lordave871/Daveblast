# Block Blast — Android Studio project

A small native Android block puzzle with a classic colorful look, 10×10 board, three pieces at a time, scoring, row/column clearing, game-over detection, and vibration when one or more lines are cleared.

## Open and build
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `BlockBlastAndroid` folder.
4. Allow Gradle to sync. If prompted, install Android SDK Platform 35 and a compatible Android Gradle plugin.
5. Connect your Android phone with USB debugging enabled, or create an emulator, then press **Run**.
6. To create an installable APK, choose **Build → Build APK(s)**. Android Studio will show the generated APK path.

## How to play
- Tap one of the three pieces at the bottom to select it.
- Tap a board cell to place the selected piece with its top-left block at that cell.
- A placement that overlaps occupied cells or extends beyond the board is rejected.
- Complete a full row or column to clear it. The phone vibrates briefly when a line clears.
- The game ends when none of the remaining pieces can fit. Tap the game-over panel to restart.

## Notes
- Vibration uses Android's native `Vibrator` API and declares `android.permission.VIBRATE`.
- This is an original block puzzle inspired by the general block-puzzle genre, not an official copy of another game's assets or branding.
- The project source is provided; this environment does not have the Android SDK/Gradle build environment required to compile and sign an APK directly.
